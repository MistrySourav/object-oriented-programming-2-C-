﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace project_1st_try
{
    public partial class Crud_UDS : Form
    {
        public Crud_UDS()
        {
            InitializeComponent();
        }

         

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();

            SqlCommand cmd = new SqlCommand("INSERT INTO tb_1 (name, id, password, email, Number, Address, Type) VALUES (@name, @id, @password, @email, @Number, @Address, @Type)", con);

            cmd.Parameters.AddWithValue("@email", email.Text.Trim());
            cmd.Parameters.AddWithValue("@id", id.Text.Trim());
            cmd.Parameters.AddWithValue("@name", name.Text.Trim());
            cmd.Parameters.AddWithValue("@password", password.Text.Trim());
            cmd.Parameters.AddWithValue("@Address", Address.Text.Trim());
            cmd.Parameters.AddWithValue("@Number", Number.Text.Trim());
            cmd.Parameters.AddWithValue("@Type", Type.Text.Trim());

            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Record inserted successfully.");

        }
        //  ;
        private void button2_Click(object sender, EventArgs e)
        {
           
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            
        }

         

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Address_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Type_TextChanged(object sender, EventArgs e)
        {

        }

        private void Number_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
        //Search
        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from tb_1 where id=@id", con);
            cmd.Parameters.AddWithValue("@id", id.Text);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
//delete
        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Delete tb_1   where id=@id ", con);
            cmd.Parameters.AddWithValue("@id", id.Text);


            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Successfully Deleted ");
        }

        //udgrade
        private void button2_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Update tb_1 set name=@name, password=@password ,email=@email,Number=@Number,Address=@Address,Type=@Type where id =@id ", con);
            cmd.Parameters.AddWithValue("@email", email.Text.Trim());
            cmd.Parameters.AddWithValue("@name", name.Text.Trim());
            cmd.Parameters.AddWithValue("@password ", password.Text.Trim());
            cmd.Parameters.AddWithValue("@Address ", Address.Text.Trim());
            cmd.Parameters.AddWithValue("@Number ", Number.Text.Trim());

            cmd.Parameters.AddWithValue("@Type ", Type.Text.Trim());
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Successfully Updated ");
        }

        private void email_TextChanged(object sender, EventArgs e)
        {

        }

        private void password_TextChanged(object sender, EventArgs e)
        {

        }

        private void id_TextChanged(object sender, EventArgs e)
        {

        }

        private void name_TextChanged(object sender, EventArgs e)
        {

        }

        private void email111_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
