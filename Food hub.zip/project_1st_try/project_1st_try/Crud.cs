﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_1st_try
{
    public partial class Crud : Form
    {
        private string userId;

        public Crud()
        {
            InitializeComponent();
            C1.CheckedChanged += C1_CheckedChanged;
            this.userId = userId;


        }
        SqlConnection connect = new SqlConnection(@" Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");


        private void R2_Click(object sender, EventArgs e)
        {
            startpage_loading f1 = new startpage_loading(userId);
            f1.Show();
            this.Hide();
        }

        private void X2_Click_1(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void L2_Click_1(object sender, EventArgs e)
        {

            if (email.Text == "" || name.Text == "" || password.Text == "" || confirmPassWord.Text == "" || id.Text == "" || Type.Text == "")
                {
                     MessageBox.Show("Please fill all blank fields", "Error message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                 }
            else
                 {
                 if (password.Text != confirmPassWord.Text)
                   {
                     MessageBox.Show("Password and Confirm Password do not match", "Error message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                     return;
                   }
 
                else if (connect.State != ConnectionState.Open)
                   {
                    try
                    {
                        connect.Open();
                        string checkname = "Select * From  tb_1 WHERE name = '" + name.Text.Trim() + " ' ";
                        using (SqlCommand checkuser = new SqlCommand(checkname, connect))
                        {

                            SqlDataAdapter adapter = new SqlDataAdapter(checkuser);
                            DataTable table = new DataTable();
                            adapter.Fill(table);
                            if (table.Rows.Count >= 1)
                            {
                                MessageBox.Show(name.Text + " is already exit", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else
                            {
                                string insertData = "INSERT INTO tb_1 (  name,id, password ,email,Number,Address,Type) "
                                   + "VALUES( @name,@id, @password ,@email,@Number,@Address,@Type )";

                                DateTime date = DateTime.Today;
                                using (SqlCommand cmd = new SqlCommand(insertData, connect))
                                {
                                    cmd.Parameters.AddWithValue("@email", email.Text.Trim());
                                    cmd.Parameters.AddWithValue("@id ", id.Text.Trim());
                                    cmd.Parameters.AddWithValue("@name", name.Text.Trim());
                                    cmd.Parameters.AddWithValue("@password ", password.Text.Trim());
                                    cmd.Parameters.AddWithValue("@Address ", Address.Text.Trim());
                                    cmd.Parameters.AddWithValue("@Number ", Number.Text.Trim());

                                    cmd.Parameters.AddWithValue("@Type ", Type.Text.Trim());



                                    ///cmd.Parameters.AddWithValue("@date", date);

                                    cmd.ExecuteNonQuery();
                                    MessageBox.Show(" Registatered succefully", "Information message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                    startpage_loading f1 = new startpage_loading(userId);
                                    f1.Show();
                                    this.Hide();
                                }

                            }



                        }

                    }

                    catch (Exception ex)
                    {
                        MessageBox.Show("Error connection connecting database: " + ex, "Error massage", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                    finally
                    {
                        connect.Close();
                    }



                }


            }
        }
        private void C1_CheckedChanged(object sender, EventArgs e)
        {
            if (C1.Checked)
            {
                password.PasswordChar = '*';
                confirmPassWord.PasswordChar = '*';
            }
            else
            {
                password.PasswordChar = ' ';
                confirmPassWord.PasswordChar = ' ';
            }
        }

        private void R2_Click_1(object sender, EventArgs e)
        {
            user_login l = new user_login(userId);
            l.Show();
            this.Hide();

        }

        private void X2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            user_login user_Sign_Up = new user_login(userId);
            user_Sign_Up.Show();
            this.Hide(); 

        }
    }
}
