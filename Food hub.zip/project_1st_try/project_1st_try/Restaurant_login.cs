﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace project_1st_try
{
    public partial class Restaurant_login : Form
    {





        private string userId;

        public Restaurant_login(string userId)
        {
            InitializeComponent();
            this.userId = userId;
        }


        void Addcontrols(Form f)
        {
            panel2.Controls.Clear();
            f.Dock = DockStyle.Fill;
            f.TopLevel = false;
            panel2.Controls.Add(f);
            f.Show();


        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            Addcontrols(new burger(userId));
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Addcontrols(new pizza(userId));

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Addcontrols(new biriyani(userId));

        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            Addcontrols(new pasta(userId));

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            Addcontrols(new drink(userId));
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Welcome w=new Welcome(userId);
            w.Show();
            this.Hide();

        }
    }
}
