﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_1st_try
{
    public partial class pasta : Form
    {
        
     
        private string userId;
 
        public pasta(string userId)
        {
            InitializeComponent();
            this.userId = userId;

        }
        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into pasta values (@name,@P_id,@P_price,@P_quantity,@R_id)", con);


            cmd.Parameters.AddWithValue("@name", name.Text);
            cmd.Parameters.AddWithValue("@P_id", P_id.Text);
            cmd.Parameters.AddWithValue("@P_price", int.Parse(P_price.Text));
            cmd.Parameters.AddWithValue("@P_quantity", int.Parse(P_quantity.Text));
            cmd.Parameters.AddWithValue("@R_id", userId);

            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("excute properly ");
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Update drink set name= @name , P_price= @P_price,P_quantity=@P_quantity where P_id =@P_id ", con);
            cmd.Parameters.AddWithValue("@P_id", P_id.Text);

            cmd.Parameters.AddWithValue("@name", name.Text);

            cmd.Parameters.AddWithValue("@P_price", int.Parse(P_price.Text));
            cmd.Parameters.AddWithValue("@P_quantity", int.Parse(P_price.Text));
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Successfully Updated ");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Delete drink   where P_id=@P_id ", con);
            cmd.Parameters.AddWithValue("@P_id", P_id.Text);


            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Successfully Deleted ");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from drink where d_id=@d_id", con);
            cmd.Parameters.AddWithValue("d_id", P_id.Text);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

          private void name_TextChanged(object sender, EventArgs e)
        {

        }

        private void d_id_TextChanged(object sender, EventArgs e)
        {

        }

        private void d_price_TextChanged(object sender, EventArgs e)
        {

        }

        private void d_quantity_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            user_login u = new user_login(userId);
            u.Show();
            this.Hide();
        }
    }
}
