﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_1st_try
{
    public partial class biriyani3 : Form
    {
        private string connectionString = "Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True";

        public biriyani3()
        {
            InitializeComponent();
            LoadBurgerData();
        }


        private void LoadBurgerData()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT name, B_price, B_quantity FROM biriyani  WHERE R_id=103", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void btnAddToCart_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                 DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                 string itemName = selectedRow.Cells["name"].Value.ToString();
                int itemPrice = Convert.ToInt32(selectedRow.Cells["B_price"].Value);
                int itemQuantity = Convert.ToInt32(selectedRow.Cells["B_quantity"].Value);

                 using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    SqlCommand insertCmd = new SqlCommand("INSERT INTO cart1 (name, price,quantity ) VALUES (@name, @price,@quantity)", con);
                    insertCmd.Parameters.AddWithValue("@name", itemName);
                    insertCmd.Parameters.AddWithValue("@quantity", itemQuantity);
                    insertCmd.Parameters.AddWithValue("@price", itemPrice);

                     insertCmd.ExecuteNonQuery();

                     MessageBox.Show("Item added to cart successfully.");

                     LoadBurgerData();
                }
            }
            else
            {
                MessageBox.Show("Please select a row before adding to cart.");
            }
        }

        
    }
}
