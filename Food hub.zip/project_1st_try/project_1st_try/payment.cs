﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_1st_try
{
    public partial class payment : Form
    {
        private decimal totalSum;

        // Constructor to receive the totalSum value
        public payment(decimal totalSum)
        {
            InitializeComponent();
            this.totalSum = totalSum;
        }

        private void payment_Load(object sender, EventArgs e)
        {
            // Display the totalSum value in label2
            label2.Text = $"Total Sum: {totalSum:C}";
        }

        private void button1_Click(object sender, EventArgs e)
        {
             online_pay p
                = new online_pay(totalSum);
            p.Show();
            this.Hide();
           //  p.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Thank you for your order.\nIt will be delivered shortly.");
        }
    }
}