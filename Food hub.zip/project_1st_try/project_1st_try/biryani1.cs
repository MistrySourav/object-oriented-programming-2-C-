﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_1st_try
{
    public partial class biryani1 : Form
    {
        private string connectionString = "Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True";

        public biryani1()
        {
            InitializeComponent();
            LoadBurgerData();
        }

     
        private void LoadBurgerData()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT name, B_price, B_quantity FROM biriyani  WHERE R_id=101", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void btnAddToCart_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Get the selected row
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                // Extract values from the selected row
                string itemName = selectedRow.Cells["name"].Value.ToString();
                int itemPrice = Convert.ToInt32(selectedRow.Cells["B_price"].Value);
                int itemQuantity = Convert.ToInt32(selectedRow.Cells["B_quantity"].Value);

                // Insert the selected data into the 'cart' table
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    SqlCommand insertCmd = new SqlCommand("INSERT INTO cart1 (name, price,quantity ) VALUES (@name, @price,@quantity)", con);
                    insertCmd.Parameters.AddWithValue("@name", itemName);
                    insertCmd.Parameters.AddWithValue("@quantity", itemQuantity);
                    insertCmd.Parameters.AddWithValue("@price", itemPrice);

                    // Execute the insert command
                    insertCmd.ExecuteNonQuery();

                    // Display a message to the user
                    MessageBox.Show("Item added to cart successfully.");

                    // Optionally, refresh the DataGridView with the updated data
                    LoadBurgerData();
                }
            }
            else
            {
                MessageBox.Show("Please select a row before adding to cart.");
            }
        }
    }
}
