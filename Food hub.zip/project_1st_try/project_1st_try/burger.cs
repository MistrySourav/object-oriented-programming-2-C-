﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace project_1st_try
{
    public partial class burger : Form
    {
     
        private string userId;

        

        public burger(string userId)
        {
            InitializeComponent();
            this.userId = userId;
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into Burger values (@name,@b_id,@b_price,@b_quantity,@R_id)", con);

            cmd.Parameters.AddWithValue("@name", name.Text);
            cmd.Parameters.AddWithValue("@b_id", b_id.Text);
            cmd.Parameters.AddWithValue("@b_price", int.Parse(b_price.Text));
            cmd.Parameters.AddWithValue("@b_quantity", int.Parse(b_quantity.Text));
            cmd.Parameters.AddWithValue("@R_id", userId); // Use userId here

            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Execute properly ");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Update Burger set name= @name , b_price= @b_price,b_quantity=@b_quantity where b_id =@b_id ", con);
            cmd.Parameters.AddWithValue("@b_id", b_id.Text);

            cmd.Parameters.AddWithValue("@name", name.Text);

            cmd.Parameters.AddWithValue("@b_price", int.Parse(b_price.Text));
            cmd.Parameters.AddWithValue("@b_quantity", int.Parse(b_price.Text));
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Successfully Updated ");
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Delete Burger   where b_id=@b_id ", con);
            cmd.Parameters.AddWithValue("@b_id", b_id.Text);


            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Successfully Deleted ");
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Burger where b_id=@b_id", con);
            cmd.Parameters.AddWithValue("@b_id", b_id.Text);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

      

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            user_login u = new user_login(userId);
            u.Show();
            this.Hide();
        }
    }
}
