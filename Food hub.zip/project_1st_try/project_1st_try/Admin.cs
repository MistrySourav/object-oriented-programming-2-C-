﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_1st_try
{
    public partial class Admin : Form
    {
        private string userId;
        public Admin()
        {
            InitializeComponent();
        }
        void Addcontrols(Form f)
        {
            panel1.Controls.Clear();
            f.Dock = DockStyle.Fill;
            f.TopLevel = false;
            panel1.Controls.Add(f);
            f.Show();


        }
        private void button2_Click(object sender, EventArgs e)
        {
            Addcontrols(new Crud_UDS());

        }

        private void button1_Click(object sender, EventArgs e)
        {
        Addcontrols(new C_crud());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            user_login u =new user_login(userId);
            u.Show();
            this.Hide();
                
        }
    }
}
