﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_1st_try
{
    public partial class Menu2 : Form
    {
        public Menu2()
        {
            InitializeComponent();
        }
        void Addcontrols(Form f)
        {
            panel3.Controls.Clear();
            f.Dock = DockStyle.Fill;
            f.TopLevel = false;
            panel3.Controls.Add(f);
            f.Show();


        }

 


        private void button6_Click_1(object sender, EventArgs e)
        {
            Addcontrols(new burger2());
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Addcontrols(new pizza2());

        }

        private void button8_Click(object sender, EventArgs e)
        {
            Addcontrols(new pasta2());
        }
        private void button9_Click(object sender, EventArgs e)
        {
            Addcontrols(new drink2());

        }

        private void button10_Click(object sender, EventArgs e)
        {
            Addcontrols(new biriyani2());

        }
        private void Menu_Load(object sender, EventArgs e)
        {

        }
    }
}
