﻿using project_2nd;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_1st_try
{
    public partial class startpage_loading : Form
    {
        private string userId;

        public startpage_loading(string userId)
        {
            InitializeComponent();
            this.userId = userId;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            panel1.Width += 3;

            if(panel1.Width >= 599)
            {
                timer1.Stop();
                user_login form = new user_login(userId);
                form.Show();
                this.Hide();
            }
        }
    }
}
