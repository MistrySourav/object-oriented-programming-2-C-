﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_1st_try
{
    public partial class drink : Form
    {
        private string userId;



        public drink(string userId)
        {
            InitializeComponent();
            this.userId = userId;

        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into drink values (@name,@d_id,@d_price,@d_quantity,@R_id)", con);


            cmd.Parameters.AddWithValue("@name", name.Text);
            cmd.Parameters.AddWithValue("@d_id", d_id.Text);
            cmd.Parameters.AddWithValue("@d_price", int.Parse(d_price.Text));
            cmd.Parameters.AddWithValue("@d_quantity", int.Parse(d_quantity.Text));
            cmd.Parameters.AddWithValue("@R_id", userId);

            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("excute properly ");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Update drink set name= @name , d_price= @d_price,d_quantity=@d_quantity where d_id =@d_id ", con);
            cmd.Parameters.AddWithValue("@d_id", d_id.Text);

            cmd.Parameters.AddWithValue("@name", name.Text);

            cmd.Parameters.AddWithValue("@d_price", int.Parse(d_price.Text));
            cmd.Parameters.AddWithValue("@d_quantity", int.Parse(d_price.Text));
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Successfully Updated ");
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Delete drink   where d_id=@d_id ", con);
            cmd.Parameters.AddWithValue("@d_id", d_id.Text);


            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Successfully Deleted ");
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from drink where d_id=@d_id", con);
            cmd.Parameters.AddWithValue("d_id", d_id.Text);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            user_login u = new user_login(userId);
            u.Show();
            this.Hide();
        }
    }
}
