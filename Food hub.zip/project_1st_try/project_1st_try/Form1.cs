﻿using project_1st_try;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_2nd
{
    public partial class user_login : Form
    {
        public user_login()
        {
            InitializeComponent();
        }
        SqlConnection connect = new SqlConnection(@"Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");


        private void login_Click_1(object sender, EventArgs e)
        {
            if (id.Text == " " || password.Text == " ")
            {
                MessageBox.Show("the boxs are empty .please fill the boxs", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (connect.State != ConnectionState.Open)
                {
                    try
                    {
                        connect.Open();
                        string data = "SELECT * FROM tb_1 WHERE password=@password AND id=@id";
                        using (SqlCommand cmd = new SqlCommand(data, connect))
                        {
                            cmd.Parameters.AddWithValue("@id", id.Text.Trim());
                            cmd.Parameters.AddWithValue("@password", password.Text.Trim());
                            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                            DataTable table = new DataTable();
                            adapter.Fill(table);
                            if (table.Rows.Count >= 1)
                            {
                                MessageBox.Show(" Logged In Successfully ", " Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                ///main_user n = new main_user();
                                ///n.Show();
                                ///this.Hide();
                            }
                            else
                            {

                                MessageBox.Show(" Incorrect Username/password ", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);

                            }

                        }
                    }

                    catch (Exception ex)
                    {
                        MessageBox.Show("Error connection connecting database: " + ex, "Error massage", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                    finally
                    {
                        connect.Close();
                    }
                }

            }
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void R2_Click(object sender, EventArgs e)
        {
            cart user_Sign_Up = new cart();
            user_Sign_Up.Show();
            this.Hide();
        }
    }
}

