﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_1st_try
{
    public partial class Menu3 : Form
    {
        public Menu3()
        {
            InitializeComponent();
        }
        void Addcontrols(Form f)
        {
            panel2.Controls.Clear();
            f.Dock = DockStyle.Fill;
            f.TopLevel = false;
            panel2.Controls.Add(f);
            f.Show();


        }




       

         

        
        private void Menu_Load(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Addcontrols(new burger3());
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            Addcontrols(new pizza3());
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            Addcontrols(new pasta3());
        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            Addcontrols(new biriyani3());
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            Addcontrols(new drink3());
        }
    }
}
