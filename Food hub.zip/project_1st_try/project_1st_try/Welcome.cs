﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_1st_try
{
    public partial class Welcome : Form
    {
        private string userId;

        public Welcome(string userId)
        {
            InitializeComponent();
            this.userId = userId;
        }
        public void Addcontrols(Form f)
        {
            panel3.Controls.Clear();
            f.Dock = DockStyle.Fill;
            f.TopLevel = false;
            panel3.Controls.Add(f);
            f.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Addcontrols(new Menu_user_show());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Addcontrols(new cart());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Addcontrols(new C_crud());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
