﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_1st_try
{
    public partial class Menu_user_show : Form
    {
        public Menu_user_show()
        {
            InitializeComponent();
        }
        void Addcontrols(Form f)
        {
            panel1.Controls.Clear();
            f.Dock = DockStyle.Fill;
            f.TopLevel = false;
            panel1.Controls.Add(f);
            f.Show();

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Addcontrols(new Menu1());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Addcontrols(new Menu2());

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Addcontrols(new Menu3());

        }
    }
}
