﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_1st_try
{
    public partial class pizza : Form
    {


        private string userId;



        public pizza(string userId)
        {
            InitializeComponent();
            this.userId = userId;

        }
        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into pizza values (@name,@p_id,pb_price,@p_quantity,@R_id)", con);


            cmd.Parameters.AddWithValue("@name", name.Text);
            cmd.Parameters.AddWithValue("@p_id", p_id.Text);
            cmd.Parameters.AddWithValue("@p_price", int.Parse(p_price.Text));
            cmd.Parameters.AddWithValue("@p_quantity", int.Parse(p_quantity.Text));
            cmd.Parameters.AddWithValue("@R_id", userId);

            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("excute properly ");
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Update pizza set name= @name , p_price= @p_price,p_quantity=@p_quantity where p_id =@p_id ", con);
            cmd.Parameters.AddWithValue("@p_id", p_id.Text);

            cmd.Parameters.AddWithValue("@name", name.Text);

            cmd.Parameters.AddWithValue("@b_price", int.Parse(p_price.Text));
            cmd.Parameters.AddWithValue("@b_quantity", int.Parse(p_price.Text));
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Successfully Updated ");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Delete pizza   where p_id=@p_id ", con);
            cmd.Parameters.AddWithValue("@p_id", p_id.Text);


            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Successfully Deleted ");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from pizza where p_id=@p_id", con);
            cmd.Parameters.AddWithValue("p_id", p_id.Text);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            user_login u=new user_login(userId);
            u.Show();
            this.Hide();    

        }
    }
}
