﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_1st_try
{
    public partial class biriyani : Form
    {
        private string userId;



        public biriyani(string userId)
        {
            InitializeComponent();
            this.userId = userId;

        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into biriyani values (@name,@B_id,@B_price,@B_quantity,@R_id)", con);


            cmd.Parameters.AddWithValue("@name", name.Text);
            cmd.Parameters.AddWithValue("@B_id", B_id.Text);
            cmd.Parameters.AddWithValue("@B_price", int.Parse(B_price.Text));
            cmd.Parameters.AddWithValue("@B_quantity", int.Parse(B_quantity.Text));
            cmd.Parameters.AddWithValue("@R_id", userId);

            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("excute properly ");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Update biriyani set name= @name , B_price= @B_price,B_quantity=@B_quantity where B_id =@B_id ", con);
            cmd.Parameters.AddWithValue("@B_id", B_id.Text);

            cmd.Parameters.AddWithValue("@name", name.Text);

            cmd.Parameters.AddWithValue("@B_price", int.Parse(B_price.Text));
            cmd.Parameters.AddWithValue("@B_quantity", int.Parse(B_price.Text));
            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Successfully Updated ");
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Delete biriyani   where B_id=@B_id ", con);
            cmd.Parameters.AddWithValue("@B_id", B_id.Text);


            cmd.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Successfully Deleted ");
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from biriyani where B_id=@B_id", con);
            cmd.Parameters.AddWithValue("B_id", B_id.Text);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        
    }
}
