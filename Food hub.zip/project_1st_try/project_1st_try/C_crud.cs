﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Xml.Linq;

namespace project_1st_try
{
    public partial class C_crud : Form
    {
        public C_crud()
        {
            InitializeComponent();
        }
  
            private void button2_Click_1(object sender, EventArgs e)
            {
                SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand("Update tb_1 set name=@name, password=@password ,email=@email,Number=@Number,Address=@Address,Type=@Type where id =@id ", con);
                cmd.Parameters.AddWithValue("@email", email.Text.Trim());
                cmd.Parameters.AddWithValue("@name", name.Text.Trim());
                cmd.Parameters.AddWithValue("@password ", password.Text.Trim());
                cmd.Parameters.AddWithValue("@Address ", Address.Text.Trim());
                cmd.Parameters.AddWithValue("@Number ", Number.Text.Trim());
                cmd.Parameters.AddWithValue("@Type ", Type.Text.Trim());
                cmd.Parameters.AddWithValue("id", id.Text);
            cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Successfully Updated ");
            }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from tb_1 where id =@id ", con);
            cmd.Parameters.AddWithValue("id", id.Text);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
    }
 }

 