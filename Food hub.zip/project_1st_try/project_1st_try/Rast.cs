﻿using project_2nd;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace project_1st_try
{
    public partial class Rast : Form
    {



        private string userId;

        public Rast(string userId)
        {
            InitializeComponent();
            this.userId = userId;
        }



        void Addcontrols(Form f)
        {
            panel2.Controls.Clear();
            f.Dock = DockStyle.Fill;
            f.TopLevel = false;
            panel2.Controls.Add(f);
            f.Show();


        }
        private void button1_Click(object sender, EventArgs e)
        {
            burger burgerForm = new burger(userId);
            Addcontrols(burgerForm);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pizza pizzaForm = new pizza(userId);
            Addcontrols(pizzaForm);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            biriyani  biriyaniForm = new biriyani(userId);
            Addcontrols(biriyaniForm);

        }

        private void button5_Click(object sender, EventArgs e)
        {

            pasta pastaForm = new pasta(userId);
            Addcontrols(pastaForm);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            drink drinkForm = new drink(userId);
            Addcontrols(drinkForm);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            user_login w = new user_login(userId);
            w.Show();
            this.Hide();
        }
    }
}
