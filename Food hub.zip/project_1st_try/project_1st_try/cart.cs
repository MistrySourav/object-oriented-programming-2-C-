﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_1st_try
{
    public partial class cart : Form
    {
        public cart()
        {
            InitializeComponent();
        }
        private decimal totalSum = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            // Call the method to refresh the DataGridView (assuming you have a method for loading data)
            LoadCartData();
        }

        // Example method for loading data into DataGridView
        private void LoadCartData()
        {
            using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True"))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT name, price, quantity FROM cart1", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                DataGridViewCheckBoxColumn chkColumn = new DataGridViewCheckBoxColumn();
                chkColumn.Name = "Select";
                chkColumn.HeaderText = "Select";
                dataGridView1.Columns.Insert(0, chkColumn);

                // Bind the DataTable to the DataGridView
                dataGridView1.DataSource = dt;
            }
        }

        private void CalculateAndDisplayTotal()
        {
            using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True"))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT SUM(price) AS TotalPrice FROM cart1", con);
                object result = cmd.ExecuteScalar();

                if (result != null && result != DBNull.Value)
                {
                    MessageBox.Show($"Total Price: {result.ToString()}", "Total Sum", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("No data in the cart.", "Total Sum", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            CalculateAndDisplayTotal();

        }
        private void DeleteSelectedRows()
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                 if (row.Cells["Select"].Value != null && (bool)row.Cells["Select"].Value)
                {
                     string itemName = row.Cells["name"].Value.ToString();

                     DeleteRowFromDatabase(itemName);

                     dataGridView1.Rows.Remove(row);
                }
            }
        }

        private void DeleteRowFromDatabase(string itemName)
        {
            using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True"))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DELETE FROM cart1 WHERE name = @itemName", con);
                cmd.Parameters.AddWithValue("@itemName", itemName);
                cmd.ExecuteNonQuery();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DeleteSelectedRows();

        }
        private void ClearCartData()
        {
            using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True"))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DELETE FROM cart1", con);
                cmd.ExecuteNonQuery();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            payment p = new payment(totalSum);
            p.Show();
            ClearCartData();
        }
    }
}