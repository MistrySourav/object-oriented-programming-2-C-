﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_1st_try
{
    public partial class pizza1 : Form
    {
        // Define the connection string
        private string connectionString = "Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True";

        public pizza1()
        {
            InitializeComponent();

            // Load data into the dataGridView1 on form load
            LoadBurgerData();
        }

        private void LoadBurgerData()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT name, p_price, p_quantity FROM pizza WHERE R_id=101", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        

        

        private void btnAddToCart_Click_1(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Get the selected row
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                // Extract values from the selected row
                string itemName = selectedRow.Cells["name"].Value.ToString();
                int itemPrice = Convert.ToInt32(selectedRow.Cells["p_price"].Value);
                int itemQuantity = Convert.ToInt32(selectedRow.Cells["p_quantity"].Value);

                // Insert the selected data into the 'cart' table
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    SqlCommand insertCmd = new SqlCommand("INSERT INTO cart1 (name, price,quantity ) VALUES (@name, @price,@quantity)", con);
                    insertCmd.Parameters.AddWithValue("@name", itemName);
                    insertCmd.Parameters.AddWithValue("@quantity", itemQuantity);
                    insertCmd.Parameters.AddWithValue("@price", itemPrice);

                    // Execute the insert command
                    insertCmd.ExecuteNonQuery();

                    // Display a message to the user
                    MessageBox.Show("Item added to cart successfully.");

                    // Optionally, refresh the DataGridView with the updated data
                    LoadBurgerData();
                }
            }
            else
            {
                MessageBox.Show("Please select a row before adding to cart.");
            }
        }
    }
}

