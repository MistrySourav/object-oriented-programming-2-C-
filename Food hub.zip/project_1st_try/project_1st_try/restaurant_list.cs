﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_1st_try
{
    public partial class restaurant_list : Form
    {

        private string userId;

        public restaurant_list(string userId)
        {
            InitializeComponent();
            this.userId = userId;
        }
        void Addcontrols(Form f)
        {
            panel2.Controls.Clear();
            f.Dock = DockStyle.Fill;
            f.TopLevel = false;
            panel2.Controls.Add(f);
            f.Show();


        }
        private void button1_Click(object sender, EventArgs e)
        {
            Rast rastForm = new Rast(userId);
            Addcontrols(rastForm);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Restaurant2 rastForm = new Restaurant2(userId);
            Addcontrols(rastForm);
 
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Restaurant3 restaurant3Form = new Restaurant3(userId);
            Addcontrols(restaurant3Form);
        }

        
    }
}
