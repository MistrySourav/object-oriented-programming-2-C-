﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_1st_try
{
    public partial class online_pay : Form
    {
        private decimal totalSum;

         public online_pay(decimal totalSum)
        {
            InitializeComponent();
            this.totalSum = totalSum;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");

            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Pay (id, Number, BkashNumber, Address, price) VALUES (@id, @name, @password, @Address, @price)", con);
                cmd.Parameters.AddWithValue("@id", id.Text.Trim());
                cmd.Parameters.AddWithValue("@name", name.Text.Trim());
                cmd.Parameters.AddWithValue("@password", Bkashnumber.Text.Trim());
                cmd.Parameters.AddWithValue("@Address", Address.Text.Trim());
                cmd.Parameters.AddWithValue("@price", totalSum); // Insert the totalSum value into the "price" column
                cmd.ExecuteNonQuery();

                MessageBox.Show("Payment information inserted successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
