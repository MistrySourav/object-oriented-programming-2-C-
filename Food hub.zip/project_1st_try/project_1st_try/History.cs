﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project_1st_try
{
    public partial class History : Form
    {
        
             private SqlConnection con = new SqlConnection("Data Source=DESKTOP-T860R9A;Initial Catalog=project_1;Integrated Security=True");

            public History()
            {
                InitializeComponent();
            }

            private void CopyDataAndDisplayInDataGridView()
            {
                try
                {
                     con.Open();

                     string copy  = "INSERT INTO history (name, price) SELECT name, price FROM cart1";
                    using (SqlCommand copyDataCommand = new SqlCommand(copy, con))
                    {
                        copyDataCommand.ExecuteNonQuery();
                    }

                     string retrieveDataQuery = "SELECT name, price FROM history";
                    using (SqlCommand retrieveDataCommand = new SqlCommand(retrieveDataQuery, con))
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter(retrieveDataCommand);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                         dataGridView1.DataSource = dataTable;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    // Close the connection
                    con.Close();
                }
            }

            private void Load(object sender, EventArgs e)
            {
                // Call the method when the form is loaded or any other appropriate event
                CopyDataAndDisplayInDataGridView();
            }
        }
}
